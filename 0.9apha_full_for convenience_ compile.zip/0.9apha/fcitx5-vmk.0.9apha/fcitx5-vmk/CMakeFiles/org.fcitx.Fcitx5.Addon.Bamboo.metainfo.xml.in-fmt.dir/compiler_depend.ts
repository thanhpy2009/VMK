# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for org.fcitx.Fcitx5.Addon.Bamboo.metainfo.xml.in-fmt.
