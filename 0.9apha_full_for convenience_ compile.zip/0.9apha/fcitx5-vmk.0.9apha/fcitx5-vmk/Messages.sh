#!/bin/bash

gen_pot cxx:appdata:ui:desktop fcitx5-bamboo po .
