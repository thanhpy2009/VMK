Text processing library for Vietnamese

## License

The MIT License (MIT)
Copyright (C) 2018 Luong Thanh Lam
